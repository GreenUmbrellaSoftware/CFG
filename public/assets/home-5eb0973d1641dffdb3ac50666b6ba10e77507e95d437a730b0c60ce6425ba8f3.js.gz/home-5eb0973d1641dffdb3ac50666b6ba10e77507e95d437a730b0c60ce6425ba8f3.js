$(document).ready(function() {
  $(".add-user").on("click", function () {
    console.info("here");

  });

  $(".reject-user").on("click", function() {
    console.info("reject this f00l")
  })
});
